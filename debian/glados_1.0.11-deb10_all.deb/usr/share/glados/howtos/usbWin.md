## Start from USB-Device (Windows 10)
https://wiki.lernstick.ch/doku.php?id=anleitungen:systemstart-uefi