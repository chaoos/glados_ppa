
<pre style="white-space: pre-wrap;"><?= $log; ?></pre>
