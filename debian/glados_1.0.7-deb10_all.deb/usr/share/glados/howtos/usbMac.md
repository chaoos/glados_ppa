## Start from USB-Device (Mac)
https://wiki.lernstick.ch/doku.php?id=anleitungen:systemstart-mac