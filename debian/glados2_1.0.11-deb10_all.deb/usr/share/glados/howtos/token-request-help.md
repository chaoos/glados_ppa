## Help: Token request

Provide the *Token* given on your *Exam Sheet* as seen below.

![Insert token](img/token.gif)

----

Your *Exam Sheet* should look like this:

![PDF of ticket](img/ticket-pdf2.png)

----

If you need help, please ask your teacher.