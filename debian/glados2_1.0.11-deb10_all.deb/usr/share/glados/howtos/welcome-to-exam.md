## Welcome to your exam

The exam has started now. 

To hand in your exam result, click the `Hand-in` icon in the dash menu. Once this process is initiated, you **cannot continue** with the exam. So, please make sure you **saved all documents** and **closed all open windows** before finishing your exam.

![Hand in 1](img/finish_exam.jpg)

You will get a notice when the last backup is done, **don't shutdown your computer** before the request message appears. Changes of the exam result from now on, will not be saved.

![Hand in 2](img/finish-exam.gif)

If you need help, please ask your teacher. You can close this window.