<?php

foreach ($errors as $logEntry) {
	echo '<samp>' . $logEntry . '</samp><br>';
}

?>
